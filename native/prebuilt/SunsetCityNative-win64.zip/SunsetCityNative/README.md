# Sunset City — native (C++ and HLSL, Direct3D 12)

The same world as the web game, as a native Windows program: C++17, Direct3D 12 and HLSL shaders
(compiled when the game starts, shader model 5.0, so any Direct3D 12 graphics card runs them).

**What is in it now**

- The whole 12 × 16 km world: coast, snowy mountains, desert, canyon, grassland, the 43 km ring motorway and its spokes.
- A procedural city on the 25 × 25 road grid: glass towers with spandrel panels and mullions, punched-window offices with
  pilasters, sills and cornices, shopfronts with awnings and sign bands, houses, roof equipment, neon blade signs, palms and
  street trees, street lamps, parked cars along the kerbs (all solid), pedestrians on the pavements.
- Wet streets: crosswalks, stop lines, worn lanes, kerbs and paving, puddles, and a real **planar reflection** of the city
  (buildings, traffic, your car, the sky and the sun) in the road.
- Traffic with signals (ported from the web game), motorway traffic, cars that get knocked about.
- **Races**: fifteen routes with checkpoint gates, timer, medals and saved best times.
- **Escape mode**: you drive an Aston Martin DB5 in Silver Birch, with its gadgets, and the police chase you (see below).
- **Real car models**: the supercar is a Ferrari 458 Spider and the gadget car and the police cars are a modern concept coupe, both modelled by other people (credits in `assets/CREDITS.md`). The wheels spin and steer, the lights work, and the driver view has a real cockpit with a steering wheel that turns with yours. If the `assets` folder is missing the game falls back to its built-in procedural cars.
- Time of day: it starts at midday (blue sky, white sun, grey asphalt); press T to ease into golden hour and back.
- Live reflections: a cube of the surroundings (city, traffic, sky) is drawn from your car, one face every other frame, and the car's paint, its glass and the building windows reflect it. F7 turns reflections off (this and the wet-road mirror) if you need the frames.
- Architecture: towers step back in offset tiers under a crown, every building has a real cornice and parapet, mid-rise blocks have belt courses and a cornice over the shopfronts, and the suburban houses have pitched tile roofs with chimneys; windows are recessed and the frame shades the glass from the sun.
- Real structure: trees are modelled with a trunk, limbs and about a thousand leaf cards each (palms and trees cast shadows with the same holes as their leaves), pedestrians are smooth humanoids with a walk cycle, and every vehicle rolls on real alloy wheels.
- Surfaces: brick courses with mortar, recessed windows with frames, curtains, blinds and lit rooms, weathering streaks, speckled and cracked asphalt with worn paint, palms with real leaflets, leafy trees with ragged edges, and reflections that see the street and its buildings instead of an empty sky.
- Rendering: cascaded shadows, ambient occlusion, 4× MSAA HDR, bloom, depth of field, camera motion blur, haze,
  golden-hour sky and clouds, particles (smoke, fire, sparks, tracers).

Not ported from the web game: the bunkers and airfield buildings, grass tufts, the map screen, sound.

## Play

Run `sunset.exe` (keep the `shaders` and `assets` folders next to it), or `play_fullscreen.bat`. If you have no compiler installed, use the
zip in [`prebuilt/`](prebuilt/), or the `SunsetCityNative-win64` artifact of the *native-windows* GitHub Action.
The menu opens when the game starts: pick **Escape the police**, **Races** or **Free roam**.

| | Keyboard | Gamepad (Xbox) |
|---|---|---|
| Throttle / brake, reverse | W S or ↑ ↓ | RT / LT |
| Steer | A D or ← → | left stick |
| Handbrake | Space | A |
| Nitro | Shift or N | X |
| Camera (wide chase, close chase, driver, hood) | C | Y |
| Look round (hold) | right mouse button | right stick |
| Gear down / up (free roam and races) | Q / E | LB / RB |
| Back on the road / restart | R | Back |
| Menu and settings | Esc or Tab | Start |
| Fullscreen | F11 | |
| Time of day (midday / golden hour) | T | |
| Stats overlay (fps, GPU time, draw calls) | F3 | |
| Vsync on/off, ambient occlusion, shadows, reflections | F4, F5, F6, F7 | |

**Escape mode gadgets** (the Aston Martin DB5 only): **F** or left mouse = machine guns (hold; they overheat), **G** = homing
missile, **B** = bomb dropped behind you (explodes when a car drives close), **O** = oil slick, **X** = smoke screen
(blocks the police's view), **V** = armour plate. On a pad: RB guns, B missile, LB bomb, D-pad up oil, down smoke, left armour.
The police see you or they don't: break line of sight and stay hidden to lose them. More heat brings more cars and heavy
pursuit trucks. You lose if you are wrecked or boxed in.

If something goes wrong the game writes `sunset_native.log` next to where you started it (including where it crashed), and
shows the failing Direct3D call in a message box. Best race times are saved in `sunset_native_saves.txt`.

**For a 1440p high-refresh display:** the game presents uncapped with tearing allowed when the display supports it (press F4
for vsync). Press F3 to see the real frame time and GPU time. If it is not fast enough, F5/F6/F7 turn ambient occlusion,
shadows and reflections off, and `--msaa 2` or `--msaa 1` lowers anti-aliasing.

## Build it

You need Windows 10 or 11, a Direct3D 12 graphics card, **Visual Studio 2022** (the "Desktop development with C++"
workload) and CMake (it comes with Visual Studio).

```
cmake -S native -B native/build -G "Visual Studio 17 2022" -A x64
cmake --build native/build --config Release
native\build\Release\sunset.exe
```

On Linux the same source cross-compiles with MinGW-w64 (`cmake -DCMAKE_TOOLCHAIN_FILE=native/cmake/mingw-w64.cmake`),
and runs under Wine (with vkd3d) for tests.

## Music

The game plays your own music during the police chase: put an MP3 or WAV file (the James Bond theme you own, for example) in the `music` folder next to `sunset.exe`. It picks a file with "bond" or "007" in its name, otherwise the first one (choose a different one in *Settings > Sound and music*, where *Open the music folder* takes you straight there). It loops, pauses with the menu and stops when the chase ends; you can also have it play all the time, and set the volume. No music comes with the game (the theme is copyrighted), and the game has no sound effects yet.

## Settings, and your steering wheel and pedals

Press **Esc** (or Tab) and choose **Settings**. Your choices are saved in `sunset_native_settings.txt` next to the game.

- **Graphics**: vsync, ambient occlusion, shadows, reflections, time of day, anti-aliasing (this one applies the next time you start the game). The F4 to F7 and T keys still work and are remembered too.
- **Steering wheel and pedals**: plug the wheel and pedals in (USB) and switch the wheel on, open *Settings > Steering wheel and pedals* and the live panel on the right shows every axis and button the game can see (move something and watch which bar follows). Then pick **Set up everything** and do what the screen says: turn the wheel fully left then fully right, press the throttle fully down, then the brake. The game finds each axis by watching what moved, so there is nothing to look up. (**Steering**, **Throttle pedal** and **Brake pedal** can also be set one at a time.) It copes with pedals that read backwards, with throttle and brake sharing one axis (the default of several wheels), and with the pedals being on a different USB device from the wheel. Then bind any wheel buttons you want (handbrake, shift paddles, camera, nitro, the gadget buttons...), and tune the sensitivity, linearity and dead zones. The wheel's hat switch moves around the menus.
- Controllers are read through **DirectInput** (eight axes including sliders, up to 64 buttons: what Logitech, Thrustmaster and Fanatec wheels are built for), and also through the older Windows joystick interface for anything DirectInput does not list. Any wheel that Windows lists under "Set up USB game controllers" should work. For a Logitech G29 put the mode switch on PS3 and install Logitech G HUB so the pedals show up as separate axes. **Force feedback is not supported yet.** Xbox controllers keep working as before.
- If nothing is found, the panel says what each interface reported, and the game writes `sunset_wheel_report.txt` next to the exe: every controller, its axes, buttons and live values, and what is currently bound. Send that file if the wheel misbehaves.
- `sunset.exe --selftest-wheel` runs the wheel logic against a simulated device (no hardware needed) and reports each check.

## Options (for testing)

```
sunset.exe --size 1920x1080 --msaa 4 --noao --noshadow
sunset.exe --spawn coast|desert|alpine|south|city|runway   where to start (default coast)
sunset.exe --day 0|1                                         time of day at the start (1 midday, the default; 0 golden hour)
sunset.exe --escape | --race N | --model super|gt           start straight in a mode, or choose the car
sunset.exe --fullscreen --vsync                             borderless fullscreen; wait for the display
sunset.exe --shot out.bmp --drive 5 --cam chase|close|driver|hood|free      save a picture and exit
sunset.exe --simulate 60 --escape                           run the game logic only, log what the police do
sunset.exe --check-shaders                                  compile every shader and list errors
sunset.exe --selftest-wheel                                 check the wheel setup and mapping logic with a simulated wheel
sunset.exe --shot out.bmp --menu 2|3|4 [--fakewheel] [--wizard]   a picture of the settings pages (4 = wheel, with a simulated wheel and the setup prompt)
sunset.exe --shot out.bmp --showcase 0..8                  one model on the ground ahead of the car: 0-5 traffic (saloon, SUV, hatchback, van, truck, bus), 6 police car, 7 pursuit truck, 8 pedestrians
```

## How it is put together

| | |
|---|---|
| `src/gfx.*` | Direct3D 12: device, swap chain, descriptor heaps, buffers and textures, a constant ring, deferred release, runtime HLSL compile |
| `src/renderer.*` | the frame: 4 shadow cascades, the 4× MSAA HDR scene, resolve, ambient occlusion, bloom, composite (grade, sharpen, tone map) |
| `src/terrain.*` | streamed terrain in three levels of detail, built on worker threads |
| `src/scenery.*`, `props.*` | roads, barriers, bridges, and the plants and rocks, per 256 m tile |
| `src/world.*` | the world: height, climate, motorway network, ground queries (a port of `src/world.js`, same numbers) |
| `src/vehicle.*`, `collide.*` | car physics and collisions (a port of `vehicle.js`, same numbers) |
| `src/city.*` | the buildings and boulevard palms, as instanced boxes whose facades are drawn in the shader |
| `src/car.*`, `bond.*`, `shapes.*`, `vehicles.*` | the supercar, the gadget grand tourer, the modelling toolkit (design-curve body lofts, wire wheels), traffic and police vehicles (the procedural versions, used for the other traffic and as a fallback) |
| `src/carasset.*`, `assets/`, `tools/` | the baked car models (`.scm` files), their loader and drawing code, and the script that converts glTF models into them |
| `src/traffic.*`, `peds.*`, `fx.*` | traffic and parked cars, pedestrians, particles |
| `src/events.*`, `escape.*` | the races, and the police chase with its weapons |
| `src/settings.*`, `wheel.*` | saved settings, and the wheel and pedals (DirectInput and the Windows joystick API, the setup wizard, mapping, buttons) |
| `src/game.*`, `hud.*`, `main.cpp` | the game state, menu and input, HUD, and the entry point |
| `shaders/*.hlsl` | sky, terrain, water, meshes, shadows, post-processing, HUD |

The world and the vehicle physics were checked against the JavaScript versions: heights, climate, road
profiles, 0–100 km/h in 3.24 s, 342 km/h top speed and a 35.9 m stop from 100 km/h all match.

## Honest notes

- It was developed without a Windows machine or a real graphics card: it is built with MinGW and rendered
  headless with Wine, vkd3d and a software Vulkan driver. Frame rates and any driver-specific problems on real
  hardware are untested. Please send the log and a screenshot if something looks wrong.
- Visual Studio's build was not run here either (the code compiles with GCC and Clang for Windows, and the
  *native-windows* GitHub Action builds it with MSVC).
