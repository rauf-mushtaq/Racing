@echo off
start "" sunset.exe --fullscreen
