@echo off
start "" sunset.exe
